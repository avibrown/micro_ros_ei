// generated from rosidl_typesupport_introspection_c/resource/idl__rosidl_typesupport_introspection_c.h.em
// with input from ei_classification:msg/EIClassification.idl
// generated code does not contain a copyright notice

#ifndef EI_CLASSIFICATION__MSG__DETAIL__EI_CLASSIFICATION__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
#define EI_CLASSIFICATION__MSG__DETAIL__EI_CLASSIFICATION__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_

#ifdef __cplusplus
extern "C"
{
#endif


#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "ei_classification/msg/rosidl_typesupport_introspection_c__visibility_control.h"

ROSIDL_TYPESUPPORT_INTROSPECTION_C_PUBLIC_ei_classification
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_c, ei_classification, msg, EIClassification)();

#ifdef __cplusplus
}
#endif

#endif  // EI_CLASSIFICATION__MSG__DETAIL__EI_CLASSIFICATION__ROSIDL_TYPESUPPORT_INTROSPECTION_C_H_
