// generated from rosidl_typesupport_microxrcedds_c/resource/idl__rosidl_typesupport_c.h.em
// with input from ei_classification:msg/EIClassification.idl
// generated code does not contain a copyright notice
#ifndef EI_CLASSIFICATION__MSG__EI_CLASSIFICATION__ROSIDL_TYPESUPPORT_MICROXRCEDDS_C_H_
#define EI_CLASSIFICATION__MSG__EI_CLASSIFICATION__ROSIDL_TYPESUPPORT_MICROXRCEDDS_C_H_


#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "ei_classification/msg/rosidl_typesupport_microxrcedds_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_MICROXRCEDDS_C_PUBLIC_ei_classification
size_t get_serialized_size_ei_classification__msg__EIClassification(
  const void * untyped_ros_message,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_MICROXRCEDDS_C_PUBLIC_ei_classification
size_t max_serialized_size_ei_classification__msg__EIClassification(
  bool * full_bounded,
  size_t current_alignment);

ROSIDL_TYPESUPPORT_MICROXRCEDDS_C_PUBLIC_ei_classification
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_microxrcedds_c, ei_classification, msg, EIClassification)();

#ifdef __cplusplus
}
#endif


#endif  // EI_CLASSIFICATION__MSG__EI_CLASSIFICATION__ROSIDL_TYPESUPPORT_MICROXRCEDDS_C_H_
