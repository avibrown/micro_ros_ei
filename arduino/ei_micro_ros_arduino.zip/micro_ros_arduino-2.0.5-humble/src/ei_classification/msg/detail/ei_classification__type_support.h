// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from ei_classification:msg/EIClassification.idl
// generated code does not contain a copyright notice

#ifndef EI_CLASSIFICATION__MSG__DETAIL__EI_CLASSIFICATION__TYPE_SUPPORT_H_
#define EI_CLASSIFICATION__MSG__DETAIL__EI_CLASSIFICATION__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "ei_classification/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_ei_classification
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  ei_classification,
  msg,
  EIClassification
)();

#ifdef __cplusplus
}
#endif

#endif  // EI_CLASSIFICATION__MSG__DETAIL__EI_CLASSIFICATION__TYPE_SUPPORT_H_
