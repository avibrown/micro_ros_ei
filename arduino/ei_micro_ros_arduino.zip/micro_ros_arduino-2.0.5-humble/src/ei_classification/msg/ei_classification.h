// generated from rosidl_generator_c/resource/idl.h.em
// with input from ei_classification:msg/EIClassification.idl
// generated code does not contain a copyright notice

#ifndef EI_CLASSIFICATION__MSG__EI_CLASSIFICATION_H_
#define EI_CLASSIFICATION__MSG__EI_CLASSIFICATION_H_

#include "ei_classification/msg/detail/ei_classification__struct.h"
#include "ei_classification/msg/detail/ei_classification__functions.h"
#include "ei_classification/msg/detail/ei_classification__type_support.h"

#endif  // EI_CLASSIFICATION__MSG__EI_CLASSIFICATION_H_
